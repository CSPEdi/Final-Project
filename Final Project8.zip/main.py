import pygame
from pygame.examples.moveit import GameObject
from pygame.locals import *
from coin import Coin
from red import Red
from bomb import Bomb
from firstplayer import FirstPlayer
from secondplayer import SecondPlayer
import random
import time

# Set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 15)
pygame.display.set_caption("Coin Collector!")

# Set up variables for the display
SCREEN_HEIGHT = 600
SCREEN_WIDTH = 800
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)

name = "Collect coins as fast as you can!"
message = "Collision not detected"
points = 0
r = 50
g = 0
b = 100
countdown = 0

start_time = time.time()
objective = 0
game_over = False

# Render the text for later
display_name = my_font.render(name, True, (255, 255, 255))
display_message = my_font.render(message, True, (255, 255, 255))
display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))
display_countdown = my_font.render("Time Left: " + str(countdown), True, (255, 255, 255))
display_high_score = my_font.render("High Score: " + str(objective), True, (255, 255, 255))

# Initialize sprites
first_player = FirstPlayer(40, 60)
second_player = SecondPlayer(280, 60)
c = Coin(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
potion = None
bo = None

# Title screen variables
instruction_text1 = "Player 1 use ASDW keys and Player 2 use arrow keys"
instruction_text2 = "Advance by working together! You have 30 seconds to collect coins"
instruction_text3 = "Click anywhere on the screen to begin!"

# End screen variables
end_text = "Game Over!"

# Load fonts
instruction_font = pygame.font.SysFont('Arial', 20)
end_font = pygame.font.SysFont('Arial', 50)

# Set frequency of appearances
red_last_spawn_time = 0
bomb_last_spawn_time = 0
red_spawn_interval = 3
bomb_spawn_interval = 3


# Functions to display text
def display_title_screen():
    instruction_render1 = instruction_font.render(instruction_text1, True, (255, 255, 255))
    instruction_render2 = instruction_font.render(instruction_text2, True, (255, 255, 255))
    instruction_render3 = instruction_font.render(instruction_text3, True, (255, 255, 255))
    screen.blit(instruction_render1, (SCREEN_WIDTH // 2 - instruction_render1.get_width() // 2, 150))
    screen.blit(instruction_render2, (SCREEN_WIDTH // 2 - instruction_render2.get_width() // 2, 170))
    screen.blit(instruction_render3, (SCREEN_WIDTH // 2 - instruction_render3.get_width() // 2, 190))


def display_end_screen():
    end_render = end_font.render(end_text, True, (255, 255, 255))
    screen.blit(end_render, (SCREEN_WIDTH // 2 - end_render.get_width() // 2, 150))


# -------- Main Program Loop -----------
run = True
display_game = False
title_screen = True

while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN and title_screen:
            title_screen = False
            start_time = time.time()
        if event.type == pygame.MOUSEBUTTONDOWN and game_over:
            game_over = False
            start_time = time.time()
            points = 0

    if title_screen:
        screen.blit(first_player.image, first_player.rect)
        screen.fill((r, g, b))
        display_title_screen()
        pygame.display.update()
    elif not game_over:
        current_time = time.time()
        time_elapsed = current_time - start_time
        time_elapsed = round(time_elapsed, 2)
        countdown = round(30 - time_elapsed, 2)
        display_countdown = my_font.render("Time Left: " + str(countdown), True, (255, 255, 255))

        if countdown <= 0:
            game_over = True
            if points > objective:
                objective = points
                display_high_score = my_font.render("High Score: " + str(objective), True, (255, 255, 255))

        if game_over:
            points = 0  # Reset points to zero

        # Logic to handle red coin appearance
        if current_time - red_last_spawn_time >= red_spawn_interval and potion is None:
            potion = Red(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
            red_last_spawn_time = current_time

        if potion and current_time - red_last_spawn_time >= red_spawn_interval:
            potion = None

        # Logic to handle bomb appearance
        if current_time - bomb_last_spawn_time >= bomb_spawn_interval and bo is None:
            bo = Bomb(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
            bomb_last_spawn_time = current_time

        if bo and current_time - bomb_last_spawn_time >= bomb_spawn_interval:
            bo = None

        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            display_game = True

        # First Player Animations
        clock = pygame.time.Clock()
        player = pygame.image.load('samurai_walk.png').convert()
        p = GameObject(player, 10, 400)
        while True:
            if keys[pygame.K_d]:
                first_player.move_direction("right")
            if keys[pygame.K_a]:
                first_player.move_direction("left")
            if keys[pygame.K_w]:
                first_player.move_direction("up")
            if keys[pygame.K_s]:
                first_player.move_direction("down")


        player2 = pygame.image.load("sword_walk.png").convert()
        p = GameObject(player2, 10, 400)
        if keys[pygame.K_RIGHT]:
            second_player.move_direction("right")
        if keys[pygame.K_LEFT]:
            second_player.move_direction("left")
        if keys[pygame.K_UP]:
            second_player.move_direction("up")
        if keys[pygame.K_DOWN]:
            second_player.move_direction("down")

        # Check for collisions between player sprites and coins
        if first_player.rect.colliderect(c.rect) or second_player.rect.colliderect(c.rect):
            c = Coin(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
            points += 10
            display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))

        # Check for collisions between player sprites and red coins
        if potion and (first_player.rect.colliderect(potion.rect) or second_player.rect.colliderect(potion.rect)):
            potion = None  # Remove the red coin
            points += 20
            display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))

        # Check for collisions between player sprites and bombs
        if bo and (first_player.rect.colliderect(bo.rect) or second_player.rect.colliderect(bo.rect)):
            bo = None  # Remove the bomb
            points -= 20
            if points < 0:
                points = 0  # Ensure points don't go negative
            display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))

    screen.fill((r, g, b))
    screen.blit(display_name, (0, 0))
    screen.blit(display_message, (0, 15))
    screen.blit(display_points, (0, 30))
    screen.blit(display_countdown, (0, 45))
    screen.blit(display_high_score, (0, 60))
    screen.blit(first_player.image, first_player.rect)
    screen.blit(c.image, c.rect)
    screen.blit(second_player.image, second_player.rect)

    if potion:
        screen.blit(potion.image, potion.rect)  # Blit red coin sprite if exists
    if bo:
        screen.blit(bo.image, bo.rect)  # Blit bomb sprite if exists
    pygame.display.update()
else:
    screen.fill((r, g, b))
    display_end_screen()
    pygame.display.update()

with open("high_score.txt", "w") as file:
    file.write(str(objective))

pygame.quit()
