import pygame
from pygame.locals import *
from fox import Fox
from wolf import Wolf
from coin import Coin
from red import Red
from bomb import Bomb
import random
import time

# Initiate pygame and give permission
# to use pygame's functionality
pygame.init()

# Create a display surface object
# of specific dimension
window = pygame.display.set_mode((600, 600))

# Create a list of different sprites
# that you want to use in the animation
image_sprite = [pygame.image.load("magewalk1.png"),
                pygame.image.load("magewalk2.png"),
                pygame.image.load("magewalk2.png"),
                pygame.image.load("magewalk2.png"),
                pygame.image.load("magewalk2.png"),
                pygame.image.load("magewalk2.png"),
                pygame.image.load("magewalk2.png"),
                ]

# Creating a new clock object to
# track the amount of time
clock = pygame.time.Clock()

# Creating a new variable
# We will use this variable to
# iterate over the sprite list
value = 0

# Creating a boolean variable that
# we will use to run the while loop
run = True

# Creating a boolean variable to
# check if the character is moving
# or not
moving = False

# Creating a variable to store
# the velocity
velocity = 12

# Starting coordinates of the sprite
x = 100
y = 150

# Creating an infinite loop
# to run our game
while run:

    # Setting the framerate to 10fps just
    # to see the result properly
    clock.tick(10)

    # iterate over the list of Event objects
    # that was returned by pygame.event.get() method.
    for event in pygame.event.get():

        # Closing the window and program if the
        # type of the event is QUIT
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()
            quit()

        # Checking event key if the type
        # of the event is KEYUP i.e.
        # keyboard button is released
        if event.type == pygame.KEYUP:

            # Setting the value of moving to False
            # and the value f value variable to 0
            # if the button released is
            # Left arrow key or right arrow key
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                moving = False
                value = 0

    # Storing the key pressed in a
    # new variable using key.get_pressed()
    # method
    key_pressed_is = pygame.key.get_pressed()

    # Changing the x coordinate
    # of the player and setting moving
    # variable to True
    if key_pressed_is[K_LEFT]:
        x -= 8
        moving = True
    if key_pressed_is[K_RIGHT]:
        x += 8
        moving = True

    # If moving variable is True
    # then increasing the value of
    # value variable by 1
    if moving:
        value += 1

    # Setting 0 in value variable if its
    # value is greater than the length
    # of our sprite list
    if value >= len(image_sprite):
        value = 0

    # Storing the sprite image in an
    # image variable
    image = image_sprite[value]

    # Scaling the image
    image = pygame.transform.scale(image, (180, 180))

    # Displaying the image in our game window
    window.blit(image, (x, y))

    # Updating the display surface
    pygame.display.update()

    # Filling the window with black color
    window.fill((0, 0, 0))

# Set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 15)
pygame.display.set_caption("Coin Collector!")

# Set up variables for the display
SCREEN_HEIGHT = 370
SCREEN_WIDTH = 530
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)

name = "Collect coins as fast as you can!"
message = "Collision not detected"
points = 0
r = 50
g = 0
b = 100
countdown = 0

start_time = time.time()
objective = 0
game_over = False

# Render the text for later
display_name = my_font.render(name, True, (255, 255, 255))
display_message = my_font.render(message, True, (255, 255, 255))
display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))
display_countdown = my_font.render("Time Left: " + str(countdown), True, (255, 255, 255))
display_high_score = my_font.render("High Score: " + str(objective), True, (255, 255, 255))

# Initialize sprites
f = Fox(40, 60)
c = Coin(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
be = Wolf(280, 60)
rc = None
bo = None

# Title screen variables
instruction_text1 = "Player 1 use ASDW keys and Player 2 use arrow keys"
instruction_text2 = "Advance by working together! You have 30 seconds to collect coins"
instruction_text3 = "Click anywhere on the screen to begin!"

# End screen variables
end_text = "Game Over!"

# Load fonts
instruction_font = pygame.font.SysFont('Arial', 20)
end_font = pygame.font.SysFont('Arial', 50)

# Set frequency of appearances
red_last_spawn_time = 0
bomb_last_spawn_time = 0
red_spawn_interval = 3
bomb_spawn_interval = 3


# Functions to display text
def display_title_screen():
    instruction_render1 = instruction_font.render(instruction_text1, True, (255, 255, 255))
    instruction_render2 = instruction_font.render(instruction_text2, True, (255, 255, 255))
    instruction_render3 = instruction_font.render(instruction_text3, True, (255, 255, 255))
    screen.blit(instruction_render1, (SCREEN_WIDTH // 2 - instruction_render1.get_width() // 2, 150))
    screen.blit(instruction_render2, (SCREEN_WIDTH // 2 - instruction_render2.get_width() // 2, 170))
    screen.blit(instruction_render3, (SCREEN_WIDTH // 2 - instruction_render3.get_width() // 2, 190))


def display_end_screen():
    end_render = end_font.render(end_text, True, (255, 255, 255))
    screen.blit(end_render, (SCREEN_WIDTH // 2 - end_render.get_width() // 2, 150))


# -------- Main Program Loop -----------
run = True
display_game = False
title_screen = True

while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN and title_screen:
            title_screen = False
            start_time = time.time()
        if event.type == pygame.MOUSEBUTTONDOWN and game_over:
            game_over = False
            start_time = time.time()
            points = 0

    if title_screen:
        screen.blit(f.image, f.rect)
        screen.fill((r, g, b))
        display_title_screen()
        pygame.display.update()
    elif not game_over:
        current_time = time.time()
        time_elapsed = current_time - start_time
        time_elapsed = round(time_elapsed, 2)
        countdown = round(30 - time_elapsed, 2)
        display_countdown = my_font.render("Time Left: " + str(countdown), True, (255, 255, 255))

        if countdown <= 0:
            game_over = True
            if points > objective:
                objective = points
                display_high_score = my_font.render("High Score: " + str(objective), True, (255, 255, 255))

        if game_over:
            points = 0  # Reset points to zero

        # Logic to handle red coin appearance
        if current_time - red_last_spawn_time >= red_spawn_interval and rc is None:
            rc = Red(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
            red_last_spawn_time = current_time

        if rc and current_time - red_last_spawn_time >= red_spawn_interval:
            rc = None

        # Logic to handle bomb appearance
        if current_time - bomb_last_spawn_time >= bomb_spawn_interval and bo is None:
            bo = Bomb(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
            bomb_last_spawn_time = current_time

        if bo and current_time - bomb_last_spawn_time >= bomb_spawn_interval:
            bo = None

        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            display_game = True

        if keys[pygame.K_d]:
            f.move_direction("right")
        if keys[pygame.K_a]:
            f.move_direction("left")
        if keys[pygame.K_w]:
            f.move_direction("up")
        if keys[pygame.K_s]:
            f.move_direction("down")

        if keys[pygame.K_RIGHT]:
            be.move_direction("right")
        if keys[pygame.K_LEFT]:
            be.move_direction("left")
        if keys[pygame.K_UP]:
            be.move_direction("up")
        if keys[pygame.K_DOWN]:
            be.move_direction("down")

        # Check for collisions between player sprites and coins
        if f.rect.colliderect(c.rect) or be.rect.colliderect(c.rect):
            c = Coin(random.randint(0, SCREEN_WIDTH), random.randint(0, SCREEN_HEIGHT))
            points += 10
            display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))

        # Check for collisions between player sprites and red coins
        if rc and (f.rect.colliderect(rc.rect) or be.rect.colliderect(rc.rect)):
            rc = None  # Remove the red coin
            points += 20
            display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))

        # Check for collisions between player sprites and bombs
        if bo and (f.rect.colliderect(bo.rect) or be.rect.colliderect(bo.rect)):
            bo = None  # Remove the bomb
            points -= 20
            if points < 0:
                points = 0  # Ensure points don't go negative
            display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        screen.fill((r, g, b))
        screen.blit(display_name, (0, 0))
        screen.blit(display_message, (0, 15))
        screen.blit(display_points, (0, 30))
        screen.blit(display_countdown, (0, 45))
        screen.blit(display_high_score, (0, 60))
        screen.blit(f.image, f.rect)
        screen.blit(c.image, c.rect)
        screen.blit(be.image, be.rect)
        if rc:
            screen.blit(rc.image, rc.rect)  # Blit red coin sprite if exists
        if bo:
            screen.blit(bo.image, bo.rect)  # Blit bomb sprite if exists
        pygame.display.update()
    else:
        screen.fill((r, g, b))
        display_end_screen()
        pygame.display.update()

    with open("high_score.txt", "w") as file:
        file.write(str(objective))

pygame.quit()
