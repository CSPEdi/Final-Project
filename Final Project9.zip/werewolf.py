import pygame


class Werewolf:
    def __init__(self, x, y):
        # Initialize attributes
        self.x = x
        self.y = y
        self.walk_images = [
            pygame.image.load(f"werewolf_walk{i + 1}.png") for i in range(8)
        ]
        self.attack_images = [
            pygame.image.load(f"werewolf_attack{i + 1}.png") for i in range(4)
        ]
        self.image = self.walk_images[0]
        self.image_size = self.image.get_size()
        self.rect = pygame.Rect(self.x, self.y, self.image_size[0], self.image_size[1])
        self.delta = -1  # Adjust the movement speed
        self.walk_frame = 0  # Track the current frame of the walking animation
        self.attack_frame = 0  # Track the current frame of the attack animation
        self.attacking = False  # Whether the wolf is attacking
        self.attack_timer = 0  # Timer for slowing down the attack animation

        # Health attributes
        self.max_health = 100
        self.current_health = self.max_health
        self.health_bar_length = 100
        self.health_ratio = self.max_health / self.health_bar_length
        self.health_bar_height = 10

        # Dialogue attributes
        self.dialogue_triggered = False
        self.dialogue_text = "I am the Wolf Boss! Prepare to be defeated!"

        # Loot attributes
        self.loot_dropped = False

    def move(self):
        # Move the enemy horizontally
        if not self.attacking:
            self.x += self.delta

            # Update the rect position
            self.rect.topleft = (self.x, self.y)

            # Cycle through walking images
            self.walk_frame = (self.walk_frame + 1) % len(self.walk_images)
            self.image = self.walk_images[self.walk_frame]

    def attack(self):
        if self.attack_timer == 0:
            self.attack_frame = (self.attack_frame + 1) % len(self.attack_images)
            self.image = self.attack_images[self.attack_frame]

        self.attack_timer = (self.attack_timer + 1) % 10

    def update(self, target):
        # Update the enemy's behavior
        if not self.attacking:
            self.move()  # Move the enemy

        # Perform attack if the target is in range
        if pygame.sprite.collide_rect(self, target):
            self.attacking = True
            if not self.dialogue_triggered:
                self.dialogue_triggered = True
        else:
            self.attacking = False

        if self.attacking:
            self.attack()

    def draw(self, screen):
        # Draw the enemy on the screen
        screen.blit(self.image, self.rect)
        self.draw_health_bar(screen)

        if self.dialogue_triggered:
            self.show_dialogue(screen)

    def draw_health_bar(self, screen):
        health_bar_width = self.current_health / self.health_ratio
        health_bar_x = self.rect.x + (self.rect.width / 2) - (self.health_bar_length / 2)
        health_bar_y = self.rect.y - 20  # Adjust to position above the wolf
        pygame.draw.rect(screen, (255, 0, 0),
                         (health_bar_x, health_bar_y, self.health_bar_length, self.health_bar_height))
        pygame.draw.rect(screen, (0, 255, 0), (health_bar_x, health_bar_y, health_bar_width, self.health_bar_height))

    def show_dialogue(self, screen):
        font = pygame.font.SysFont('Arial', 20)
        text_surface = font.render(self.dialogue_text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=(screen.get_width() // 2, screen.get_height() - 50))
        dialogue_box_rect = pygame.Rect(text_rect.x - 10, text_rect.y - 10, text_rect.width + 20, text_rect.height + 20)
        pygame.draw.rect(screen, (0, 0, 0), dialogue_box_rect)
        pygame.draw.rect(screen, (255, 255, 255), dialogue_box_rect, 2)
        screen.blit(text_surface, text_rect)

    def take_damage(self, player):
        if self.rect.colliderect(player.rect):
            self.current_health -= 10
            self.health_bar_length -= 10
        elif self.current_health < 0:
            self.health_bar_length = 0

    def is_dead(self):
        return self.current_health <= 0

    def drop_loot(self):
        if self.is_dead() and not self.loot_dropped:
            self.loot_dropped = True
            return True  # Indicate that loot should be dropped
        return False
