import pygame


class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill()

        self.rect = self.image.get_rect()
        self.rect.y = y
        self.rect.x = x


# Wall init

wall_list = pygame.sprite.Group()

# Pygame definitions

screen = pygame.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])
pygame.display.set_caption('test!')
all_sprite_list = pygame.sprite.Group()

# Left wall
wall = Wall(0, 0, 10, 600)
wall_list.add(wall)
all_sprite_list.add(wall)
# top wall
wall = Wall(10, 0, 790, 10)
wall_list.add(wall)
all_sprite_list.add(wall)

# Right wall
wall = Wall(790, 0, 10, 600)
wall_list.add(wall)
all_sprite_list.add(wall)

# Bottom wall
wall = Wall(0, 590, 1000, 300)
wall_list.add(wall)
all_sprite_list.add(wall)

# Create the player
player = Player(50, 50)
all_sprite_list.add(player)
player.walls = wall_list

player2 = Player2(50, 50, player)
all_sprite_list.add(player2)
player2.walls = wall_list

clock = pygame.time.Clock()

# Loop

done = False

while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True


        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                player.changespeed(-3, 0)
            elif event.key == pygame.K_d:
                player.changespeed(3, 0)
            elif event.key == pygame.K_w:
                player.changespeed(0, -3)
            elif event.key == pygame.K_s:
                player.changespeed(0, 3)

        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                player.changespeed(3, 0)
            elif event.key == pygame.K_d:
                player.changespeed(-3, 0)
            elif event.key == pygame.K_w:
                player.changespeed(0, 3)
            elif event.key == pygame.K_s:
                player.changespeed(0, -3)

    all_sprite_list.update()
    screen.fill(BLACK)
    all_sprite_list.draw(screen)
    pygame.display.flip()
    clock.tick(60)
    pygame.display.flip()

pygame.quit()
