import pygame
from pygame.locals import *
from elixir import Elixer
from player import Player
from werewolf import Werewolf
import random
import time

# Set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Comic Sans', 15)
pygame.display.set_caption("Dungeon Crawler!")

# Set up variables for the display
SCREEN_HEIGHT = 700
SCREEN_WIDTH = 1000
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)

name = "Advance through the dungeon"
message = "Collision not detected"
points = 0
r = 50
g = 0
b = 100
countdown = 0

start_time = time.time()
objective = 0
game_over = False
dialogue_active = False
dialogue_text = ""

# Render the text for later
display_name = my_font.render(name, True, (255, 255, 255))
display_message = my_font.render(message, True, (255, 255, 255))
display_points = my_font.render("Points: " + str(points), True, (255, 255, 255))
display_countdown = my_font.render("Time Left: " + str(countdown), True, (255, 255, 255))
display_high_score = my_font.render("High Score: " + str(objective), True, (255, 255, 255))

# Load character images
samurai_images = [pygame.image.load(f"samurai_walk{i + 1}.png") for i in range(6)]
samurai_attack_images = [pygame.image.load(f"samurai_attack{i + 1}.png") for i in range(5)]
samurai_charge_images = [pygame.image.load(f"samurai_charge{i + 1}.png") for i in range(6)]
samurai_dead_images = [pygame.image.load(f"samurai_dead{i + 1}.png") for i in range(5)]
ninja_images = [pygame.image.load(f"ninja_walk{i + 1}.png") for i in range(6)]
ninja_attack_images = [pygame.image.load(f"ninja_attack{i + 1}.png") for i in range(4)]
ninja_charge_images = [pygame.image.load(f"ninja_charge{i + 1}.png") for i in range(6)]
ninja_dead_images = [pygame.image.load(f"ninja_dead{i + 1}.png") for i in range(6)]

# Initialize variables for character selection
characters = [
    {"name": "Samurai", "images": samurai_images, "attack_images": samurai_attack_images,
     "alt_attack_images": samurai_charge_images, "dead_images": samurai_dead_images},
    {"name": "Ninja", "images": ninja_images, "attack_images": ninja_attack_images,
     "alt_attack_images": ninja_charge_images, "dead_images": ninja_dead_images}
]

selected_character_index = 0
selected_character_images = samurai_images
selected_character_attack_images = samurai_attack_images
selected_character_alt_attack_images = samurai_charge_images  # Placeholder for alternate attack images
selected_character_dead_images = samurai_dead_images

# Title screen variables
instruction_text1 = "Use ASDW keys for moving. R and T for attacking"
instruction_text2 = "Defeat dungeon bosses"
instruction_text3 = "Click anywhere on the screen to begin!"

# End screen variables
end_text = "Game Over!"

# Load fonts
instruction_font = pygame.font.SysFont('Comic Sans', 20)
end_font = pygame.font.SysFont('Comic Sans', 50)

# Load background image
background = pygame.image.load('background_image.jpg').convert()
background_rect = background.get_rect()


# Scrollable background
def draw_background(scroll_x):
    screen.blit(background, (scroll_x, 0))


# Functions to display text
def display_title_screen():
    screen.fill((r, g, b))
    instruction_render1 = instruction_font.render(instruction_text1, True, (255, 255, 255))
    instruction_render2 = instruction_font.render(instruction_text2, True, (255, 255, 255))
    instruction_render3 = instruction_font.render(instruction_text3, True, (255, 255, 255))

    # Calculate total height of text surfaces
    total_height = instruction_render1.get_height() + instruction_render2.get_height() + instruction_render3.get_height()

    # Calculate vertical position for each text surface
    y_offset = (SCREEN_HEIGHT - total_height) // 2
    y1 = y_offset
    y2 = y1 + instruction_render1.get_height() + 10  # Add some vertical spacing between texts
    y3 = y2 + instruction_render2.get_height() + 10  # Add some vertical spacing between texts

    # Center horizontally and blit each text surface
    screen.blit(instruction_render1, (SCREEN_WIDTH // 2 - instruction_render1.get_width() // 2, y1))
    screen.blit(instruction_render2, (SCREEN_WIDTH // 2 - instruction_render2.get_width() // 2, y2))
    screen.blit(instruction_render3, (SCREEN_WIDTH // 2 - instruction_render3.get_width() // 2, y3))

    pygame.display.update()


def display_end_screen():
    screen.fill((r, g, b))
    end_render = end_font.render(end_text, True, (255, 255, 255))
    screen.blit(end_render, (SCREEN_WIDTH // 2 - end_render.get_width() // 2, 150))
    pygame.display.update()


def display_character_selection():
    screen.fill((r, g, b))
    instruction_render = instruction_font.render(
        "Select your character using left and right arrow keys. Press Enter to confirm.", True, (255, 255, 255))
    screen.blit(instruction_render, (SCREEN_WIDTH // 2 - instruction_render.get_width() // 2, 100))

    character_name = characters[selected_character_index]["name"]
    character_name_render = end_font.render(character_name, True, (255, 255, 255))
    screen.blit(character_name_render, (SCREEN_WIDTH // 2 - character_name_render.get_width() // 2, 200))

    character_profile = [pygame.image.load("samurai_profile.png", "ninja_profile.png")]

    pygame.display.update()


def display_dialogue(screen, text):
    font = pygame.font.SysFont('Comic Sans', 20)
    text_render = font.render(text, True, (255, 255, 255))
    dialogue_box = pygame.Surface((SCREEN_WIDTH, 50))
    dialogue_box.fill((0, 0, 0))  # Fill the dialogue box with black color
    dialogue_box.blit(text_render, (SCREEN_WIDTH // 2 - text_render.get_width() // 2, 10))
    screen.blit(dialogue_box, (0, SCREEN_HEIGHT - 50))
    pygame.display.flip()


# Initialize sprites
player = None
wolf_boss = Werewolf(800, 450)
e = Elixer(random.randint(0, SCREEN_WIDTH), random.randint(500, 500))

# Game state variables
game_state = "title"

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == QUIT:
            running = False
        elif event.type == MOUSEBUTTONDOWN:
            if game_state == "title":
                game_state = "character_selection"
        elif event.type == KEYDOWN:
            if game_state == "character_selection":
                if event.key == K_LEFT:
                    selected_character_index = (selected_character_index - 1) % len(characters)
                    selected_character_images = characters[selected_character_index]["images"]
                    selected_character_attack_images = characters[selected_character_index]["attack_images"]
                    selected_character_alt_attack_images = characters[selected_character_index]["alt_attack_images"]
                    selected_character_dead_images = characters[selected_character_index]["dead_images"]
                elif event.key == K_RIGHT:
                    selected_character_index = (selected_character_index + 1) % len(characters)
                    selected_character_images = characters[selected_character_index]["images"]
                    selected_character_attack_images = characters[selected_character_index]["attack_images"]
                    selected_character_alt_attack_images = characters[selected_character_index]["alt_attack_images"]
                    selected_character_dead_images = characters[selected_character_index]["dead_images"]
                elif event.key == K_RETURN:
                    player = Player(40, 400, selected_character_images, selected_character_attack_images,
                                    selected_character_alt_attack_images, selected_character_dead_images)
                    game_state = "playing"
            elif game_state == "playing":
                if event.key == K_ESCAPE:
                    game_state = "title"
                elif event.key == K_t:  # Check if "T" key is pressed
                    # Switch to the alternate attack mode
                    player.toggle_attack_mode()

    if game_state == "title":
        display_title_screen()
    elif game_state == "character_selection":
        display_character_selection()
    elif game_state == "playing":
        # Update game logic
        keys = pygame.key.get_pressed()
        if keys[K_a]:
            player.move_direction("left", selected_character_attack_images, selected_character_alt_attack_images,
                                  selected_character_dead_images)
        elif keys[K_d]:
            # Call move_direction method with all required arguments
            player.move_direction("right", selected_character_attack_images, selected_character_alt_attack_images,
                                  selected_character_dead_images)
        if keys[K_r]:
            player.move_direction("attack", selected_character_attack_images, selected_character_alt_attack_images,
                                  selected_character_dead_images)

        # Update WolfBoss logic
        wolf_boss.update(player)  # self moving
        wolf_boss.take_damage(player)
        wolf_boss.is_dead()

        # Update Player Logic
        player.attack_werewolf(wolf_boss)
        player.ur_dead()

        # Check for collisions and update points, countdown, etc.
        if player.rect.colliderect(e.rect):
            player.current_health += 10
            e = Elixer(random.randint(0, SCREEN_WIDTH), random.randint(500, 500))

        # Draw everything
        draw_background(0)
        screen.blit(player.image, player.rect.topleft)
        wolf_boss.draw(screen)
        player.draw(screen)
        screen.blit(e.image, e.rect.topleft)

        # Update the display
        pygame.display.update()

pygame.quit()
