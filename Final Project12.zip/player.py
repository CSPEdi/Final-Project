import pygame


class Player:
    def __init__(self, x, y, images, attack_images, alt_attack_images):
        self.frame = 0
        self.attacking = False
        self.attack_frame = 0
        self.health = 100
        self.x = x
        self.y = y
        self.images = images
        self.attack_images = attack_images
        self.alt_attack_images = alt_attack_images
        self.image = self.images[self.frame]
        self.image_size = self.image.get_size()
        self.rect = pygame.Rect(self.x, self.y, self.image_size[0], self.image_size[1])
        self.delta = 1
        self.attack_timer = 0
        self.alt_attack_mode = False

        # Health attributes
        self.max_health = 100
        self.current_health = self.max_health
        self.health_bar_length = 100
        self.health_ratio = self.max_health / self.health_bar_length
        self.health_bar_height = 10

    def move_direction(self, direction, attack_images, alt_attack_images):
        # Movement
        if direction == "right":
            self.x += self.delta
        elif direction == "left":
            self.x -= self.delta
        elif direction == "attack" and not self.attacking:
            self.attacking = True
            self.frame = 0  # Reset frame for smooth transition
            self.attack_frame = 0  # Reset attack frame

        # Update the rect position
        self.rect.topleft = (self.x, self.y)

        # Cycle through images for animation
        if not self.attacking:
            self.frame = (self.frame + 1) % len(self.images)
            self.image = self.images[self.frame]
        else:
            if self.attack_timer == 0:
                # Select attack images based on the current attack mode
                images = attack_images if not self.alt_attack_mode else alt_attack_images
                self.attack_frame = (self.attack_frame + 1) % len(images)
                self.image = images[self.attack_frame]

            self.attack_timer = (self.attack_timer + 1) % 10
            if self.attack_timer == 0 and self.attack_frame == len(attack_images) - 1:
                self.attacking = False
                self.image = self.images[self.frame]  # Return to the original state

    def draw(self, screen):
        # Draw the enemy on the screen
        screen.blit(self.image, self.rect)
        self.draw_health_bar(screen)

    def draw_health_bar(self, screen):
        health_bar_width = self.current_health / self.health_ratio
        health_bar_x = self.rect.x + (self.rect.width / 2) - (self.health_bar_length / 2)
        health_bar_y = self.rect.y - 20  # Adjust to position above the wolf
        pygame.draw.rect(screen, (255, 0, 0),
                         (health_bar_x, health_bar_y, self.health_bar_length, self.health_bar_height))
        pygame.draw.rect(screen, (0, 255, 0), (health_bar_x, health_bar_y, health_bar_width, self.health_bar_height))

    def attack_werewolf(self, werewolf):
        if self.rect.colliderect(werewolf.rect):
            self.current_health -= 0.1
            self.health_bar_length = self.current_health

    def toggle_attack_mode(self):
        self.alt_attack_mode = not self.alt_attack_mode
